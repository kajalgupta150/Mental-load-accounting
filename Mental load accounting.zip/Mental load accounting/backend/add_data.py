import sqlite3
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "database", "mental_load.db")

conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

sample_data = [
    ("Work", 15),
    ("Family", 10),
    ("Study", 12),
    ("Health", 6)
]

cursor.executemany(
    "INSERT INTO mental_load (category, load_score) VALUES (?, ?)",
    sample_data
)

conn.commit()
conn.close()

print("✅ Sample data inserted")
