import sqlite3
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "..", "database", "mental_load.db")

def get_dashboard_data():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # total tasks
    cur.execute("SELECT COUNT(*) FROM mental_load")
    total_tasks = cur.fetchone()[0]

    # total load
    cur.execute("SELECT SUM(load) FROM mental_load")
    total_load = cur.fetchone()[0] or 0

    # category distribution
    cur.execute("""
        SELECT category, SUM(load)
        FROM mental_load
        GROUP BY category
    """)
    rows = cur.fetchall()

    categories = [r[0] for r in rows]
    category_values = [r[1] for r in rows]

    # daily load
    cur.execute("""
        SELECT date, SUM(load)
        FROM mental_load
        GROUP BY date
        ORDER BY date
    """)
    drows = cur.fetchall()

    days = [r[0] for r in drows]
    daily_values = [r[1] for r in drows]

    conn.close()

    top_category = categories[category_values.index(max(category_values))] if categories else "-"

    return {
        "summary": {
            "total_tasks": total_tasks,
            "total_load": total_load,
            "top_category": top_category
        },
        "category": {
            "labels": categories,
            "values": category_values
        },
        "daily": {
            "labels": days,
            "values": daily_values
        }
    }
