fetch("http://127.0.0.1:5000/api/dashboard")
    .then(res => res.json())
    .then(data => {

        // SUMMARY
        document.getElementById("tasks").innerText = data.summary.total_tasks;
        document.getElementById("load").innerText = data.summary.total_load;
        document.getElementById("category").innerText = data.summary.top_category;

        // PIE CHART
        new Chart(document.getElementById("pieChart"), {
            type: "pie",
            data: {
                labels: data.category.labels,
                datasets: [{
                    data: data.category.values
                }]
            }
        });

        // BAR CHART
        new Chart(document.getElementById("barChart"), {
            type: "bar",
            data: {
                labels: data.daily.labels,
                datasets: [{
                    label: "Mental Load",
                    data: data.daily.values
                }]
            }
        });

    })
    .catch(err => console.error(err));
