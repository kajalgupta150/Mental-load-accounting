# Mental Load Accounting System

A **personal mental load management dashboard** to track daily tasks, mental cost, and provide AI insights for better decision making.

---

## Features

- Track daily tasks and mental load
- Dynamic **tasks table** & **category charts**
- **Daily trend line chart**
- **Adjusted energy** and **burnout alerts**
- **Add new tasks** via frontend form
- **AI insights & suggestions** for task prioritization
- Responsive design (mobile & desktop)

---

## Tech Stack

- **Backend:** Python, Flask, SQLite
- **Frontend:** HTML, CSS, JavaScript, Chart.js
- **APIs:** REST endpoints for tasks, summary, daily trends, insights
- **CORS enabled** for frontend-backend communication

---

## Folder Structure

