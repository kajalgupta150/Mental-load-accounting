from flask import Flask, render_template, request
import sqlite3
import os
from datetime import datetime

# =========================
# App Configuration
# =========================
app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "database", "mental_load.db")

# =========================
# UI Theme Configuration 🎨
# =========================
THEME_COLORS = {
    "header_pink": "#ec4899",
    "chart_pinks": [
        "#fce7f3",
        "#fbcfe8",
        "#f9a8d4",
        "#f472b6",
        "#db2777"
    ]
}

# =========================
# Database Utilities
# =========================
def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def initialize_database():
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS mental_load (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task TEXT NOT NULL,
                category TEXT NOT NULL,
                load_score INTEGER NOT NULL,
                month TEXT NOT NULL
            )
        """)
        cursor.execute("SELECT COUNT(*) FROM mental_load")
        if cursor.fetchone()[0] == 0:
            demo_data = [
                ("Cooking", "Home", 3, "Jan"),
                ("Cleaning", "Home", 4, "Jan"),
                ("Emails", "Work", 2, "Jan"),
                ("Office Work", "Work", 5, "Jan"),
                ("Child Care", "Family", 4, "Jan"),
                ("Cooking", "Home", 2, "Feb"),
                ("Emails", "Work", 3, "Feb"),
                ("Child Care", "Family", 5, "Feb"),
                ("Meetings", "Work", 4, "Mar"),
                ("House Repair", "Home", 3, "Mar")
            ]
            cursor.executemany(
                "INSERT INTO mental_load (task, category, load_score, month) VALUES (?,?,?,?)",
                demo_data
            )
            conn.commit()

# =========================
# AI Insight Engine
# =========================
def generate_ai_insights(total_load, total_tasks, top_category):
    insights = []
    if total_load >= 30:
        insights.append("⚠️ Overall mental load is high. Risk of burnout detected.")
    elif total_load >= 20:
        insights.append("⚠️ Moderate mental load. Balance improvements recommended.")
    if total_tasks > 8:
        insights.append("📌 Too many parallel responsibilities detected.")
    if top_category:
        insights.append(f"🧠 '{top_category}' contributes the most to your stress.")
    if not insights:
        insights.append("✅ Mental workload is balanced.")
    return " ".join(insights)

# =========================
# Stress Recommendation Engine
# =========================
def generate_stress_recommendations(category, total_load):
    if category == "Work":
        suggestions = [
            "💼 Use time-blocking to avoid multitasking",
            "📵 Disable notifications after work hours",
            "📆 Reserve no-meeting focus time"
        ]
    elif category == "Home":
        suggestions = [
            "🏠 Simplify routines",
            "🧹 Share responsibilities",
            "🕯️ Schedule short recovery breaks"
        ]
    elif category == "Family":
        suggestions = [
            "❤️ Set emotional boundaries",
            "🧘 Practice guilt-free self-care",
            "🤝 Ask for support when needed"
        ]
    else:
        suggestions = [
            "🌸 Practice mindfulness",
            "🚶 Take short walks",
            "📝 Focus on high-impact tasks"
        ]

    stress_level = "Low"
    if total_load >= 30:
        stress_level = "High"
    elif total_load >= 20:
        stress_level = "Medium"

    return {
        "stress_level": stress_level,
        "suggestions": suggestions
    }

# =========================
# Dashboard Data Service
# =========================
def fetch_dashboard_data(category_filter="All", month_filter="All"):
    with get_db_connection() as conn:
        cursor = conn.cursor()

        # Aggregate for charts and summary
        query = """
            SELECT category,
                   SUM(load_score) AS total_load,
                   COUNT(*) AS total_tasks
            FROM mental_load
            WHERE 1=1
        """
        params = []

        if category_filter != "All":
            query += " AND category=?"
            params.append(category_filter)

        if month_filter != "All":
            query += " AND month=?"
            params.append(month_filter)

        query += " GROUP BY category"
        cursor.execute(query, params)
        rows = cursor.fetchall()

        categories = [r["category"] for r in rows]
        values = [r["total_load"] for r in rows]

        total_tasks = sum(r["total_tasks"] for r in rows)
        total_load = sum(r["total_load"] for r in rows)
        top_category = max(rows, key=lambda x: x["total_load"])["category"] if rows else "General"

        # Monthly Trend
        cursor.execute("SELECT month, SUM(load_score) AS total FROM mental_load GROUP BY month")
        trend = cursor.fetchall()
        trend_months = [r["month"] for r in trend]
        trend_values = [r["total"] for r in trend]

        # Filters
        cursor.execute("SELECT DISTINCT category FROM mental_load")
        all_categories = [r["category"] for r in cursor.fetchall()]

        cursor.execute("SELECT DISTINCT month FROM mental_load")
        all_months = [r["month"] for r in cursor.fetchall()]

        # AI Engines
        ai_insight = generate_ai_insights(total_load, total_tasks, top_category)
        ai_recommendation = generate_stress_recommendations(top_category, total_load)

        # Prediction
        predicted_next_load = int(total_load * 1.05)
        prediction_reason = "Prediction based on recent workload trend with a 5% growth assumption"

        # -------------------------
        # Detailed Table (tasks per category)
        # -------------------------
        table_query = """
            SELECT category, task, load_score
            FROM mental_load
            WHERE 1=1
        """
        table_params = []

        if category_filter != "All":
            table_query += " AND category=?"
            table_params.append(category_filter)

        if month_filter != "All":
            table_query += " AND month=?"
            table_params.append(month_filter)

        table_query += " ORDER BY category"
        cursor.execute(table_query, table_params)
        table_rows = cursor.fetchall()
        detailed_table = [(r["category"], r["task"], r["load_score"]) for r in table_rows]

    return {
        "categories": categories,
        "values": values,
        "pie_labels": categories,
        "pie_values": values,
        "trend_months": trend_months,
        "trend_values": trend_values,
        "table_data": detailed_table,
        "total_tasks": total_tasks,
        "total_load": total_load,
        "top_category": top_category,
        "predicted_next_load": predicted_next_load,
        "prediction_reason": prediction_reason,
        "all_categories": all_categories,
        "all_months": all_months,
        "ai_insight": ai_insight,
        "ai_recommendation": ai_recommendation
    }

# =========================
# Routes
# =========================
@app.route("/")
def home():
    return "<h3>Mental Load Accounting App</h3><a href='/dashboard'>Open Dashboard</a>"

@app.route("/dashboard")
def dashboard():
    initialize_database()
    category_filter = request.args.get("category", "All")
    month_filter = request.args.get("month", "All")

    data = fetch_dashboard_data(category_filter, month_filter)

    return render_template(
        "dashboard.html",
        **data,
        theme=THEME_COLORS,
        current_filter=category_filter,
        current_month=month_filter,
        generated_date=datetime.now().strftime("%d %b %Y")
    )

# =========================
# App Runner
# =========================
if __name__ == "__main__":
    app.run(debug=True)
