from models import add_task
from mental_cost import calculate_mental_cost

# Example: Insert multiple tasks dynamically
tasks = [
    {
        "task_name": "Study Python",
        "duration": 120,
        "urgency": 4,
        "complexity": 3,
        "context_switch": True,
        "date": "2026-01-17"
    },
    {
        "task_name": "College Assignment",
        "duration": 90,
        "urgency": 5,
        "complexity": 4,
        "context_switch": False,
        "date": "2026-01-17"
    },
    {
        "task_name": "Gym Workout",
        "duration": 60,
        "urgency": 3,
        "complexity": 2,
        "context_switch": False,
        "date": "2026-01-17"
    }
]

for task in tasks:
    mental_cost = calculate_mental_cost(
        task["duration"],
        task["urgency"],
        task["complexity"],
        task["context_switch"]
    )

    add_task(
        task_name=task["task_name"],
        duration=task["duration"],
        urgency=task["urgency"],
        complexity=task["complexity"],
        mental_cost=mental_cost,
        date=task["date"]
    )

print("✅ Tasks inserted with automatic mental cost")
