import sqlite3
import os

# Database path (same logic as db.py)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "..", "database", "mental_load.db")

def add_daily_budget(date, base_energy, adjusted_energy):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
    INSERT OR REPLACE INTO daily_budget (date, base_energy, adjusted_energy)
    VALUES (?, ?, ?)
    """, (date, base_energy, adjusted_energy))

    conn.commit()
    conn.close()

def add_task(task_name, duration, urgency, complexity, mental_cost, date):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO tasks 
    (task_name, duration, urgency, complexity, mental_cost, date)
    VALUES (?, ?, ?, ?, ?, ?)
    """, (task_name, duration, urgency, complexity, mental_cost, date))

    conn.commit()
    conn.close()

# ---------- TEST DATA ----------
if __name__ == "__main__":
    # Add daily mental budget
    add_daily_budget(
        date="2026-01-17",
        base_energy=100,
        adjusted_energy=90
    )

    # Add sample tasks
    add_task(
        task_name="Study Python",
        duration=120,
        urgency=4,
        complexity=3,
        mental_cost=85.5,
        date="2026-01-17"
    )

    add_task(
        task_name="College Assignment",
        duration=90,
        urgency=5,
        complexity=4,
        mental_cost=110.0,
        date="2026-01-17"
    )

    print("✅ Sample data inserted successfully")
