import sqlite3

DB_FILE = "mental_load.db"

def get_db_connection():
    conn = sqlite3.connect(DB_FILE)
    return conn

# Create table if not exists
def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS mental_load (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category TEXT NOT NULL,
        load_score INTEGER NOT NULL,
        date TEXT DEFAULT (DATE('now'))
    )
    """)
    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
    print("Database initialized and table ready.")
