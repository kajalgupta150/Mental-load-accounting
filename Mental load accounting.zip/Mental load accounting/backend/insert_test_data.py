import sqlite3
from datetime import datetime

DB_PATH = "mental_load.db"

data = [
    ("Work", 5, "2026-01-20"),
    ("Home", 3, "2026-01-19"),
    ("Personal", 2, "2026-01-18"),
    ("Work", 4, "2026-01-17"),
    ("Home", 6, "2026-01-16"),
]

conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

for category, load_score, date in data:
    cursor.execute(
        "INSERT INTO mental_load (category, load_score, date) VALUES (?, ?, ?)",
        (category, load_score, date)
    )

conn.commit()
conn.close()
print("Test data inserted successfully!")
